DROP TABLE IF EXISTS `#__owncloudconnect_utilisateurs`;
DROP TABLE IF EXISTS `#__owncloudconnect_url`;